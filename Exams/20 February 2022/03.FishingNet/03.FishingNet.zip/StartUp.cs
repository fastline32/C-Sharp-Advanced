﻿using System;

namespace FishingNet
{
    public class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
